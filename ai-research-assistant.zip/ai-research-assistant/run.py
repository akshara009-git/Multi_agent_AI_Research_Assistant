import subprocess, sys
sys.exit(subprocess.call([sys.executable, "-m", "streamlit", "run", "app/main.py"]))
