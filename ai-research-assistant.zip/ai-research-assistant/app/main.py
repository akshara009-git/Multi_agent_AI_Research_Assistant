import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import streamlit as st
from app.config import load_settings
from app.pipeline import Pipeline, Session
from app.citations import format_reference

st.set_page_config(page_title="AI Research Assistant", page_icon="🔬", layout="wide")
st.markdown("""<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600&family=Inter:wght@400;500;600&display=swap');
html,body,[class*="css"]{font-family:'Inter',sans-serif}
.stApp{background:radial-gradient(1200px 500px at 15% -10%,#12335a55,transparent),#0a1424}
.hero{padding:2.2rem 2rem;border-radius:20px;background:linear-gradient(120deg,#0e2a4d,#12435f 55%,#155e75);border:1px solid #1e4a73;margin-bottom:1.2rem}
.hero h1{font-family:'Fraunces',serif;font-size:2.4rem;margin:0;color:#e0f2fe;letter-spacing:-.5px}
.hero p{color:#9fd3ee;margin:.4rem 0 0}
.chip{display:inline-block;padding:2px 10px;border-radius:999px;font-size:.78rem;background:#0c3b5a;color:#7dd3fc;border:1px solid #1d5f8a;margin-right:6px}
.hi{background:#064e3b;color:#6ee7b7;border-color:#0f766e}.me{background:#1e3a8a;color:#bfdbfe;border-color:#3b82f6}.lo{background:#334155;color:#cbd5e1;border-color:#64748b}
.step{padding:6px 12px;border-left:3px solid #38bdf8;margin:4px 0;background:#0f1d33;border-radius:0 8px 8px 0;color:#bae6fd;font-size:.92rem}
div[data-testid="stExpander"]{background:#0f1d33;border:1px solid #1e3a5f;border-radius:14px}
.stButton>button{border-radius:10px;border:1px solid #1e4a73;background:#0f2a47;color:#bae6fd}
.stButton>button:hover{border-color:#38bdf8;color:#fff}
</style>""", unsafe_allow_html=True)

settings = load_settings()
if "session" not in st.session_state:
    st.session_state.session = Session(); st.session_state.result = None
    st.session_state.pipeline = Pipeline(settings) if not settings.problems() else None
S: Session = st.session_state.session

st.markdown('<div class="hero"><h1>AI Research Assistant</h1><p>Ask any research question. It searches four academic databases, reads open-access papers, and answers with traceable citations.</p></div>', unsafe_allow_html=True)
for p in settings.problems(): st.error(p)

ACTIONS = {"Find Papers": "find_papers", "Summarize": "summarize", "Compare": "compare", "Literature Review": "literature_review", "Research Gaps": "gap_analysis", "Research Ideas": "ideas"}
q = st.text_area("Research question", placeholder="e.g. What are the research gaps in federated learning for healthcare?", height=90, label_visibility="collapsed")
cols = st.columns([1.2] + [1] * 6)
go = cols[0].button("Research", type="primary", use_container_width=True)
mode = None
for c, (lab, m) in zip(cols[1:], ACTIONS.items()):
    if c.button(lab, use_container_width=True): mode, go = m, True

if go and q.strip() and st.session_state.pipeline:
    with st.status("Researching…", expanded=True) as stat:
        res = st.session_state.pipeline.run(S, q, mode, on_step=lambda m: st.write("✓ " + m))
        stat.update(label="Failed" if res.error else f"Done in {res.seconds}s", state="error" if res.error else "complete")
    st.session_state.result = res
elif go and not q.strip(): st.warning("Type a question first.")

R = st.session_state.result
if R:
    if R.error: st.error(R.error)
    for w in R.warnings: st.warning(w)
    t = st.tabs(["Analysis", "Papers", "Evidence", "Pipeline", "References"])
    with t[0]:
        st.markdown(R.answer or "_No answer generated._")
        if R.query: st.caption(f"Intent: {R.query.intent} · Topic: {R.query.topic} · Years: {R.query.year_start or '—'}–{R.query.year_end or '—'}")
    with t[1]:
        for i, p in enumerate(R.papers, 1):
            with st.expander(f"[{i}] {p.title} ({p.year or 'n.d.'}) · relevance {p.score:.2f}"):
                st.markdown(f"**Authors:** {', '.join(p.authors[:8]) or 'Not reported'}  \n**Venue:** {p.venue or 'Not reported'}  \n**Citations:** {p.citations if p.citations is not None else 'Not reported'}")
                st.markdown(f"<span class='chip'>{' + '.join(p.sources)}</span><span class='chip {'hi' if p.full_text else 'lo'}'>{'full text read' if p.full_text else 'abstract/metadata only'}</span>", unsafe_allow_html=True)
                st.write(p.abstract or "_Abstract not available._"); st.caption("Why relevant: " + p.why)
                link = f"https://doi.org/{p.doi}" if p.doi else p.url
                if link: st.link_button("View Paper", link)
                key = p.doi or p.title
                if st.checkbox("Use in Analysis", key=f"pin{i}{key[:20]}", value=key in S.pinned): S.pinned.add(key)
                else: S.pinned.discard(key)
        if S.pinned: st.info(f"{len(S.pinned)} pinned paper(s) will be used in the next analysis. Uncheck to release.")
    with t[2]:
        for e in R.evidence:
            c = {"HIGH": "hi", "MEDIUM": "me", "LOW": "lo"}[e.confidence]; p = R.papers[e.paper_idx - 1]
            st.markdown(f"<span class='chip {c}'>{e.confidence}</span><span class='chip'>[{e.paper_idx}] {p.short()[:70]}</span><span class='chip'>{e.source_type} · p.{e.page or '—'} · {e.section or 'no section'} · sim {e.score}</span>", unsafe_allow_html=True)
            st.caption(e.text[:600]); st.caption(f"Provenance: evidence → {e.source_type} → {p.title[:60]} → {('doi:' + p.doi) if p.doi else p.url or 'no DOI'}")
    with t[3]:
        for s_ in R.steps: st.markdown(f"<div class='step'>✓ {s_}</div>", unsafe_allow_html=True)
        for k, v in R.status.items(): st.caption(f"{k}: {v['ok']} ok, {v['failed']} failed")
    with t[4]:
        for ref in R.references: st.markdown(ref)
