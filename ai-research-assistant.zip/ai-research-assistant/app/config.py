import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


@dataclass
class Settings:
    openai_key: str = ""
    model: str = "gpt-4o-mini"
    embed_model: str = "text-embedding-3-small"
    s2_key: str = ""
    openalex_key: str = ""
    crossref_email: str = ""
    arxiv_enabled: bool = True
    cache_dir: Path = ROOT / "data" / "cache"

    def problems(self) -> list[str]:
        return [] if self.openai_key else ["OPENAI_API_KEY is missing. Copy .env.example to .env and set it."]


def load_settings() -> Settings:
    g = lambda k, d="": os.getenv(k, d).strip()
    return Settings(
        openai_key=g("OPENAI_API_KEY"), model=g("OPENAI_MODEL", "gpt-4o-mini"),
        embed_model=g("OPENAI_EMBED_MODEL", "text-embedding-3-small"),
        s2_key=g("SEMANTIC_SCHOLAR_API_KEY"), openalex_key=g("OPENALEX_API_KEY"),
        crossref_email=g("CROSSREF_EMAIL"), arxiv_enabled=g("ARXIV_ENABLED", "true").lower() != "false")
