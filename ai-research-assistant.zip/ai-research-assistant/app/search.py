import re, threading
from abc import ABC, abstractmethod
from difflib import SequenceMatcher
import xml.etree.ElementTree as ET
import httpx
from .models import Paper
from .utils import DiskCache, Throttle, get_logger, retry

log = get_logger("search")
HEAD = {"User-Agent": "ai-research-assistant/1.0 (academic project)"}


class RateLimited(Exception): pass


class AcademicSearchProvider(ABC):
    name = "base"
    reliability = 0.8
    interval = 1.0

    def __init__(self, cache: DiskCache):
        self.cache = cache; self.th = Throttle(self.interval)

    def _get(self, url, params=None, headers=None, as_text=False):
        key = f"{url}|{sorted((params or {}).items())}"
        hit = self.cache.get(key)
        if hit is not None: return hit
        def call():
            self.th.wait()
            r = httpx.get(url, params=params, headers={**HEAD, **(headers or {})}, timeout=20, follow_redirects=True)
            if r.status_code == 429:
                import time; time.sleep(min(float(r.headers.get("Retry-After", 3) or 3), 10)); raise RateLimited(url)
            r.raise_for_status()
            return r.text if as_text else r.json()
        data = retry(call, attempts=3, base=1.5, log=log)
        self.cache.set(key, data); return data

    def search(self, query: str, limit: int = 15, year_start=None) -> list[Paper]:
        try: out = self._search(query, limit, year_start)
        except Exception as e:
            log.warning("%s failed for %r: %s", self.name, query, str(e)[:120]); raise
        for p in out: p.sources = [self.name]
        return out

    @abstractmethod
    def _search(self, query, limit, year_start) -> list[Paper]: ...


def clean_doi(d): return re.sub(r"^https?://(dx\.)?doi\.org/", "", (d or "").strip(), flags=re.I).lower()
def strip_tags(s): return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", s or "")).strip()


class SemanticScholarProvider(AcademicSearchProvider):
    name = "Semantic Scholar"; reliability = 0.9
    def __init__(self, cache, key=""):
        super().__init__(cache); self.key = key; self.interval = 1.1 if key else 3.0; self.th = Throttle(self.interval)

    def _search(self, q, limit, ys):
        params = {"query": q, "limit": min(limit, 30), "fields": "title,authors,year,abstract,venue,citationCount,externalIds,url,openAccessPdf,publicationTypes,fieldsOfStudy"}
        if ys: params["year"] = f"{ys}-"
        d = self._get("https://api.semanticscholar.org/graph/v1/paper/search", params, {"x-api-key": self.key} if self.key else None)
        out = []
        for x in d.get("data", []):
            if not x.get("title"): continue
            ex = x.get("externalIds") or {}
            out.append(Paper(title=x["title"], authors=[a.get("name", "") for a in x.get("authors") or []], year=x.get("year"),
                abstract=x.get("abstract") or "", doi=clean_doi(ex.get("DOI")), venue=x.get("venue") or "", citations=x.get("citationCount"),
                url=x.get("url") or "", pdf_url=(x.get("openAccessPdf") or {}).get("url") or "", pub_type=",".join(x.get("publicationTypes") or []),
                topics=x.get("fieldsOfStudy") or [], ids={"s2": x.get("paperId", ""), **({"arxiv": ex["ArXiv"]} if ex.get("ArXiv") else {})}))
        return out


class OpenAlexProvider(AcademicSearchProvider):
    name = "OpenAlex"; reliability = 0.85; interval = 0.3
    def __init__(self, cache, key="", email=""):
        super().__init__(cache); self.key = key; self.email = email

    @staticmethod
    def invert(idx):
        if not idx: return ""
        w = {}
        for word, pos in idx.items():
            for p in pos: w[p] = word
        return " ".join(w[i] for i in sorted(w))

    def _search(self, q, limit, ys):
        params = {"search": q, "per-page": min(limit, 50)}
        if ys: params["filter"] = f"from_publication_date:{ys}-01-01"
        if self.key: params["api_key"] = self.key
        if self.email: params["mailto"] = self.email
        d = self._get("https://api.openalex.org/works", params)
        out = []
        for x in d.get("results", []):
            t = x.get("display_name") or x.get("title")
            if not t: continue
            src = ((x.get("primary_location") or {}).get("source") or {})
            out.append(Paper(title=t, authors=[(a.get("author") or {}).get("display_name", "") for a in x.get("authorships") or []],
                year=x.get("publication_year"), abstract=self.invert(x.get("abstract_inverted_index")), doi=clean_doi(x.get("doi")),
                venue=src.get("display_name") or "", citations=x.get("cited_by_count"), url=x.get("doi") or x.get("id") or "",
                pdf_url=(x.get("open_access") or {}).get("oa_url") or "", pub_type=x.get("type") or "",
                topics=[c.get("display_name", "") for c in (x.get("topics") or [])[:5]], ids={"openalex": x.get("id", "")}))
        return out


class CrossrefProvider(AcademicSearchProvider):
    name = "Crossref"; reliability = 0.75; interval = 0.5
    def __init__(self, cache, email=""): super().__init__(cache); self.email = email

    def _search(self, q, limit, ys):
        params = {"query": q, "rows": min(limit, 30), "select": "title,author,issued,DOI,container-title,abstract,is-referenced-by-count,URL,type,link,subject"}
        if ys: params["filter"] = f"from-pub-date:{ys}"
        if self.email: params["mailto"] = self.email
        d = self._get("https://api.crossref.org/works", params)
        out = []
        for x in (d.get("message") or {}).get("items", []):
            if not x.get("title"): continue
            dp = ((x.get("issued") or {}).get("date-parts") or [[None]])[0]
            pdf = next((l["URL"] for l in x.get("link") or [] if "pdf" in (l.get("content-type") or "")), "")
            out.append(Paper(title=strip_tags(x["title"][0]), authors=[f"{a.get('given', '')} {a.get('family', '')}".strip() for a in x.get("author") or []],
                year=dp[0] if dp else None, abstract=strip_tags(x.get("abstract")), doi=clean_doi(x.get("DOI")),
                venue=(x.get("container-title") or [""])[0], citations=x.get("is-referenced-by-count"), url=x.get("URL") or "",
                pdf_url=pdf, pub_type=x.get("type") or "", topics=x.get("subject") or []))
        return out


class ArxivProvider(AcademicSearchProvider):
    name = "arXiv"; reliability = 0.7; interval = 3.1
    NS = {"a": "http://www.w3.org/2005/Atom"}

    def _search(self, q, limit, ys):
        words = re.findall(r"[A-Za-z0-9\-]+", q)[:8]
        if not words: return []
        params = {"search_query": " AND ".join(f"all:{w}" for w in words), "max_results": min(limit, 30), "sortBy": "relevance"}
        root = ET.fromstring(self._get("https://export.arxiv.org/api/query", params, as_text=True))
        out = []
        for e in root.findall("a:entry", self.NS):
            g = lambda t: (e.findtext(f"a:{t}", "", self.NS) or "").strip()
            year = int(g("published")[:4]) if g("published")[:4].isdigit() else None
            if ys and year and year < ys: continue
            aid = g("id").rsplit("/abs/", 1)[-1]
            doi = e.findtext("{http://arxiv.org/schemas/atom}doi", "") or ""
            out.append(Paper(title=re.sub(r"\s+", " ", g("title")), authors=[a.findtext("a:name", "", self.NS) for a in e.findall("a:author", self.NS)],
                year=year, abstract=re.sub(r"\s+", " ", g("summary")), doi=clean_doi(doi), venue="arXiv preprint", url=g("id"),
                pdf_url=f"https://arxiv.org/pdf/{aid}", pub_type="preprint", ids={"arxiv": aid}))
        return out


def build_providers(s, cache):
    ps = [SemanticScholarProvider(cache, s.s2_key), OpenAlexProvider(cache, s.openalex_key, s.crossref_email), CrossrefProvider(cache, s.crossref_email)]
    if s.arxiv_enabled: ps.append(ArxivProvider(cache))
    return ps


def norm_title(t): return re.sub(r"[^a-z0-9]+", " ", (t or "").lower()).strip()
def _last(a): return a.split()[-1].lower() if a.split() else ""


def _same(a: Paper, b: Paper) -> bool:
    if a.doi and b.doi: return a.doi == b.doi
    for k, v in a.ids.items():
        if v and b.ids.get(k) == v: return True
    ta, tb = norm_title(a.title), norm_title(b.title)
    if ta == tb: return True
    if a.year and b.year and abs(a.year - b.year) > 1: return False
    ov = {_last(x) for x in a.authors[:5]} & {_last(x) for x in b.authors[:5]}
    return bool(ov) and SequenceMatcher(None, ta, tb).ratio() > 0.92


def merge(a: Paper, b: Paper) -> Paper:
    for f in ("abstract", "doi", "venue", "url", "pdf_url", "pub_type"):
        if len(getattr(b, f) or "") > len(getattr(a, f) or ""): setattr(a, f, getattr(b, f))
    a.year = a.year or b.year; a.authors = a.authors or b.authors
    a.citations = max([c for c in (a.citations, b.citations) if c is not None], default=None)
    a.topics = list(dict.fromkeys(a.topics + b.topics)); a.sources = list(dict.fromkeys(a.sources + b.sources)); a.ids = {**b.ids, **a.ids}
    return a


def deduplicate(papers: list[Paper]) -> list[Paper]:
    out: list[Paper] = []
    for p in papers:
        for i, q in enumerate(out):
            if _same(q, p): out[i] = merge(q, p); break
        else: out.append(p)
    return out


def search_all(providers, queries, limit, year_start=None):
    """Parallel across providers (sequential per provider so throttling is respected). Returns (papers, status)."""
    results, status, lock = [], {}, threading.Lock()
    def run(p):
        ok = fail = 0
        for q in queries:
            try:
                r = p.search(q, limit, year_start); ok += 1
                with lock: results.extend(r)
            except Exception: fail += 1
        status[p.name] = {"ok": ok, "failed": fail}
    ts = [threading.Thread(target=run, args=(p,)) for p in providers]
    [t.start() for t in ts]; [t.join() for t in ts]
    return results, status
