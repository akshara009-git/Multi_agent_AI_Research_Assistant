import re
from .models import Paper

CITE = re.compile(r"\[(\d+(?:\s*[,;–-]\s*\d+)*)\]")


def validate(answer: str, n_papers: int):
    """Strip citations that do not map to a retrieved paper. Returns (clean_answer, used_indices, invalid_indices)."""
    used, bad = set(), set()
    def fix(m):
        nums = [int(x) for x in re.findall(r"\d+", m.group(1))]
        good = [x for x in nums if 1 <= x <= n_papers]
        bad.update(x for x in nums if x not in good); used.update(good)
        return "[" + ", ".join(map(str, good)) + "]" if good else ""
    return CITE.sub(fix, answer), sorted(used), sorted(bad)


def uncited_paragraphs(answer: str) -> int:
    return sum(1 for p in answer.split("\n\n") if len(p) > 200 and not CITE.search(p) and not p.lstrip().startswith("|"))


def format_reference(i: int, p: Paper) -> str:
    au = ", ".join(p.authors[:3]) + (" et al." if len(p.authors) > 3 else "") if p.authors else "Unknown authors"
    link = f"https://doi.org/{p.doi}" if p.doi else p.url
    return f"[{i}] {au}. {p.title}. {p.venue or 'Venue not reported'}, {p.year or 'n.d.'}." + (f" DOI: {p.doi}" if p.doi else "") + (f" {link}" if link and not p.doi else "")
