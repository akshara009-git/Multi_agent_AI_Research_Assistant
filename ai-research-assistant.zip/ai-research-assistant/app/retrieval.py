import hashlib, io, re
import httpx
import numpy as np
from .models import Paper
from .utils import DiskCache, get_logger

log = get_logger("retrieval")
SECTIONS = re.compile(r"^\s*(?:\d+\.?\s*)?(abstract|introduction|related work|background|methods?|methodology|experiments?|results|discussion|limitations|conclusions?|future work|references)\s*$", re.I)


def extract_pdf(url: str, cache: DiskCache, max_pages=20):
    """Return [(page_no, text)] or [] on any failure. Public URLs only; no paywall bypass."""
    hit = cache.get("pdf|" + url)
    if hit is not None: return [tuple(x) for x in hit]
    pages = []
    try:
        r = httpx.get(url, timeout=30, follow_redirects=True, headers={"User-Agent": "ai-research-assistant/1.0"})
        if r.status_code == 200 and r.content[:5] == b"%PDF-" and len(r.content) < 25_000_000:
            from pypdf import PdfReader
            rd = PdfReader(io.BytesIO(r.content))
            for i, pg in enumerate(rd.pages[:max_pages], 1):
                try: t = (pg.extract_text() or "").strip()
                except Exception: t = ""
                if t: pages.append((i, t))
    except Exception as e:
        log.warning("pdf failed %s: %s", url[:80], str(e)[:100])
    cache.set("pdf|" + url, pages); return pages


def chunk_pages(pages, size=900, overlap=150):
    """pages: [(page, text)] -> [{text,page,section}]"""
    out, sec = [], ""
    for pg, txt in pages:
        buf = ""
        for line in txt.splitlines():
            m = SECTIONS.match(line)
            if m: sec = m.group(1).title()
            buf += line.strip() + " "
        buf = re.sub(r"\s+", " ", buf).strip(); i = 0
        while i < len(buf):
            out.append({"text": buf[i:i + size], "page": pg, "section": sec}); i += size - overlap
    return out


class Embedder:
    """OpenAI embeddings; falls back to hashed bag-of-words if the API is unavailable (consistent per instance)."""
    DIM = 512
    def __init__(self, settings, cache: DiskCache):
        self.s, self.cache, self.mode = settings, cache, "openai" if settings.openai_key else "hash"
        self.client = None

    def _hash(self, t):
        v = np.zeros(self.DIM, dtype=np.float32)
        for w in re.findall(r"[a-z0-9]{2,}", t.lower()): v[int(hashlib.md5(w.encode()).hexdigest(), 16) % self.DIM] += 1
        return v

    def embed(self, texts):
        if not texts: return np.zeros((0, self.DIM), dtype=np.float32)
        if self.mode == "openai":
            try:
                from openai import OpenAI
                self.client = self.client or OpenAI(api_key=self.s.openai_key, timeout=60)
                keys = [f"emb|{self.s.embed_model}|{hashlib.md5(t.encode()).hexdigest()}" for t in texts]
                vecs = [self.cache.get(k) for k in keys]
                todo = [i for i, v in enumerate(vecs) if v is None]
                for b in range(0, len(todo), 64):
                    idx = todo[b:b + 64]
                    r = self.client.embeddings.create(model=self.s.embed_model, input=[texts[i][:6000] for i in idx])
                    for i, d in zip(idx, r.data): vecs[i] = d.embedding; self.cache.set(keys[i], d.embedding)
                m = np.array(vecs, dtype=np.float32)
            except Exception as e:
                log.warning("embedding API failed, using local hashing: %s", type(e).__name__); self.mode = "hash"
                return self.embed(texts)
        else:
            m = np.stack([self._hash(t) for t in texts])
        return m / (np.linalg.norm(m, axis=1, keepdims=True) + 1e-9)


class VectorStore:
    """In-memory cosine-similarity store (numpy). Swap for FAISS/Chroma by keeping this interface."""
    def __init__(self, embedder): self.e = embedder; self.meta = []; self.mat = None

    def add(self, items):
        if not items: return
        v = self.e.embed([i["text"] for i in items]); self.meta += items
        self.mat = v if self.mat is None else np.vstack([self.mat, v])

    def search(self, query, k=12, per_paper=3):
        if self.mat is None: return []
        sims = self.mat @ self.e.embed([query])[0]; res, cnt = [], {}
        for i in np.argsort(-sims):
            m = self.meta[i]; c = cnt.get(m["paper"], 0)
            if c >= per_paper: continue
            cnt[m["paper"]] = c + 1; res.append({**m, "score": float(sims[i])})
            if len(res) >= k: break
        return res
