import math, re
from datetime import date
from .models import Paper, ResearchQuery
from .search import norm_title

REL = {"Semantic Scholar": 0.9, "OpenAlex": 0.85, "Crossref": 0.75, "arXiv": 0.7}
STOP = set("the of and for in on to a an with using based by from is are what how which about papers paper research recent latest".split())


def terms(s): return {w for w in re.findall(r"[a-z0-9]{3,}", s.lower()) if w not in STOP}


def rank(papers: list[Paper], q: ResearchQuery, embedder) -> list[Paper]:
    if not papers: return []
    qtext = " ".join([q.topic] + q.subtopics + q.entities)
    qv = embedder.embed([qtext])[0]
    pv = embedder.embed([f"{p.title}. {p.abstract[:1500]}" for p in papers])
    sims = pv @ qv; qt = terms(qtext); now = date.today().year
    for p, s in zip(papers, sims):
        sem = max(0.0, min(1.0, float(s)))
        kw = len(qt & terms(p.title + " " + p.abstract)) / max(1, len(qt))
        age = now - p.year if p.year else 6
        rec = max(0.0, 1 - age / 10) if q.wants_recent else max(0.0, 1 - age / 20)
        cit = min(1.0, math.log1p(p.citations or 0) / 8) * (0.5 + 0.5 * min(1, max(0, 3 - age) / 3 + 0.5))
        src = sum(REL.get(x, 0.6) for x in p.sources) / max(1, len(p.sources)) + 0.05 * (len(p.sources) - 1)
        miss = 0.0 if p.abstract else -0.15
        p.score = round(max(0.0, 0.45 * sem + 0.25 * kw + 0.12 * rec + 0.10 * cit + 0.08 * min(src, 1) + miss), 4)
        p.why = f"semantic {sem:.2f}, keyword overlap {kw:.2f}, recency {rec:.2f}, citations {p.citations if p.citations is not None else 'n/a'}, found in {', '.join(p.sources)}" + ("" if p.abstract else "; no abstract available")
    return sorted(papers, key=lambda p: -p.score)
