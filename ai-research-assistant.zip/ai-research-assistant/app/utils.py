import hashlib, json, logging, re, threading, time
from pathlib import Path


def get_logger(name="research"):
    lg = logging.getLogger(name)
    if not lg.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        lg.addHandler(h); lg.setLevel(logging.INFO)
    return lg


class DiskCache:
    """JSON file cache with TTL."""
    def __init__(self, root, ttl=86400):
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True); self.ttl = ttl

    def _p(self, k): return self.root / (hashlib.sha256(k.encode()).hexdigest() + ".json")

    def get(self, k):
        p = self._p(k)
        if p.exists() and time.time() - p.stat().st_mtime < self.ttl:
            try: return json.loads(p.read_text("utf-8"))
            except Exception: return None

    def set(self, k, v):
        try: self._p(k).write_text(json.dumps(v), "utf-8")
        except Exception: pass


class Throttle:
    def __init__(self, min_interval): self.i = min_interval; self.t = 0.0; self.l = threading.Lock()

    def wait(self):
        with self.l:
            d = self.t + self.i - time.time()
            if d > 0: time.sleep(d)
            self.t = time.time()


def retry(fn, attempts=3, base=1.0, log=None):
    for i in range(attempts):
        try: return fn()
        except Exception as e:
            if i == attempts - 1: raise
            if log: log.warning("retry %d after error: %s", i + 1, str(e)[:120])
            time.sleep(base * 2 ** i)


def sanitize(q: str, max_len=1200) -> str:
    return re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", " ", q or "").strip()[:max_len]
