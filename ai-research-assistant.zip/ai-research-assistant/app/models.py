from typing import Optional
from pydantic import BaseModel, Field


class Paper(BaseModel):
    title: str
    authors: list[str] = []
    year: Optional[int] = None
    abstract: str = ""
    doi: str = ""
    venue: str = ""
    citations: Optional[int] = None
    url: str = ""
    pdf_url: str = ""
    pub_type: str = ""
    topics: list[str] = []
    sources: list[str] = []
    ids: dict[str, str] = {}
    score: float = 0.0
    why: str = ""
    full_text: bool = False

    def short(self) -> str:
        a = (self.authors[0].split()[-1] + (" et al." if len(self.authors) > 1 else "")) if self.authors else "Unknown authors"
        return f"{a}, {self.title}, {self.year or 'n.d.'}"


class ResearchQuery(BaseModel):
    intent: str = "find_papers"  # explain | find_papers | summarize | compare | literature_review | gap_analysis | ideas | qa
    topic: str = ""
    subtopics: list[str] = []
    entities: list[str] = []
    domain: str = ""
    methodology_requirements: str = ""
    search_queries: list[str] = Field(default_factory=list)
    year_start: Optional[int] = None
    year_end: Optional[int] = None
    num_papers: int = 10
    needs_academic_retrieval: bool = True
    needs_comparison: bool = False
    needs_gap_analysis: bool = False
    wants_recent: bool = False
    use_previous_papers: bool = False
    needs_full_text: bool = False
    clarification: str = ""


class Evidence(BaseModel):
    paper_idx: int  # 1-based index into selected papers
    text: str
    page: Optional[int] = None
    section: str = ""
    source_type: str = "abstract"  # full_text | abstract
    score: float = 0.0
    confidence: str = "LOW"
