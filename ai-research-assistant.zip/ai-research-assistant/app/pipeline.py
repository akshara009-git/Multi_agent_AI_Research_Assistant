import time
from datetime import date
from dataclasses import dataclass, field
from . import prompts
from .citations import format_reference, uncited_paragraphs, validate
from .config import Settings, load_settings
from .llm import LLMError, LLMProvider, OpenAIProvider
from .models import Evidence, Paper, ResearchQuery
from .ranking import rank
from .retrieval import Embedder, VectorStore, chunk_pages, extract_pdf
from .search import build_providers, deduplicate, search_all
from .utils import DiskCache, get_logger, sanitize

log = get_logger("pipeline")


@dataclass
class Session:
    history: list = field(default_factory=list)
    papers: list = field(default_factory=list)
    topic: str = ""
    pinned: set = field(default_factory=set)


@dataclass
class Result:
    question: str = ""
    query: ResearchQuery | None = None
    answer: str = ""
    papers: list = field(default_factory=list)
    evidence: list = field(default_factory=list)
    references: list = field(default_factory=list)
    steps: list = field(default_factory=list)
    status: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    error: str = ""
    seconds: float = 0.0


class Pipeline:
    def __init__(self, settings: Settings | None = None, llm: LLMProvider | None = None, providers=None):
        self.s = settings or load_settings()
        self.cache = DiskCache(self.s.cache_dir, ttl=7 * 86400)
        self.llm = llm or OpenAIProvider(self.s.openai_key, self.s.model)
        self.providers = providers if providers is not None else build_providers(self.s, self.cache)
        self.embedder = Embedder(self.s, self.cache)

    def understand(self, session: Session, question: str, mode: str | None) -> ResearchQuery:
        ctx = "\n".join(f"{r}: {t[:300]}" for r, t in session.history[-6:]) or "(none)"
        user = f"Current year: {date.today().year}\nPrevious topic: {session.topic or '(none)'}\nPreviously retrieved papers: {len(session.papers)}\nConversation:\n{ctx}\n\nUser message: {question}" + (f"\nUser pressed the '{mode}' action: set intent accordingly." if mode else "")
        q = self.llm.structured(prompts.UNDERSTAND.format(year=date.today().year), user, ResearchQuery)
        if mode: q.intent = mode
        q.num_papers = max(3, min(20, q.num_papers))
        if not q.search_queries: q.search_queries = [q.topic or question]
        return q

    def run(self, session: Session, question: str, mode: str | None = None, on_step=None) -> Result:
        t0 = time.time(); question = sanitize(question); r = Result(question=question)
        def step(msg):
            r.steps.append(msg); log.info(msg)
            if on_step: on_step(msg)
        if len(question) < 3: r.error = "Please enter a research question."; return r
        try:
            q = r.query = self.understand(session, question, mode)
            step(f"Question understood: intent={q.intent}, topic='{q.topic}'")
            if q.clarification: r.answer = q.clarification; return r
            if not q.needs_academic_retrieval and q.intent in ("explain", "qa"):
                r.answer = self.llm.complete(prompts.COMMON + "\n" + prompts.MODES["explain"], f"Question: {question}\nNo literature was retrieved; state clearly that this is model-generated background knowledge.")
                r.answer = "> *Model-generated background explanation, no literature retrieved.*\n\n" + r.answer
                step("Answered from model knowledge (no retrieval needed)"); return self._finish(session, r, t0)
            pool = [p for p in session.papers if (p.doi or p.title) in session.pinned] if session.pinned else []
            if not pool and q.use_previous_papers and session.papers: pool = session.papers[:q.num_papers]
            if pool:
                step(f"Reusing {len(pool)} previously retrieved/pinned papers")
                ranked = pool
            else:
                step(f"Generated {len(q.search_queries)} search queries: " + " | ".join(q.search_queries))
                raw, r.status = search_all(self.providers, q.search_queries, 15, q.year_start)
                alive = [k for k, v in r.status.items() if v["ok"]]
                step(f"Searched {len(alive)}/{len(self.providers)} databases, {len(raw)} raw results")
                for k, v in r.status.items():
                    if v["failed"]: r.warnings.append(f"{k}: {v['failed']} request(s) failed (continued with other sources)")
                if not raw:
                    r.error = "No academic source returned results (they may be unreachable or rate-limited). Nothing was generated to avoid hallucination."; return self._finish(session, r, t0, keep=False)
                papers = deduplicate(raw); step(f"{len(raw) - len(papers)} duplicates removed, {len(papers)} unique papers")
                if q.year_start: papers = [p for p in papers if not p.year or p.year >= q.year_start]
                if q.year_end: papers = [p for p in papers if not p.year or p.year <= q.year_end]
                ranked = rank(papers, q, self.embedder)
            selected = ranked[:q.num_papers]; session.papers = ranked; session.topic = q.topic or session.topic
            r.papers = selected; step(f"{len(selected)} relevant papers selected")
            store = VectorStore(self.embedder); full = 0
            for i, p in enumerate(selected, 1):
                items = []
                if p.pdf_url and i <= 6 and q.intent != "find_papers":
                    ch = chunk_pages(extract_pdf(p.pdf_url, self.cache))
                    if ch: p.full_text = True; full += 1; items += [{**c, "paper": i, "type": "full_text"} for c in ch]
                if p.abstract: items += [{"text": p.abstract, "page": None, "section": "Abstract", "paper": i, "type": "abstract"}]
                store.add(items)
            step(f"{full} open-access PDFs processed; remaining papers use abstract/metadata only")
            ev = []
            for qq in [q.topic or question] + q.subtopics[:3]:
                ev += store.search(qq + " " + (question if qq != question else ""), k=10, per_paper=2)
            seen, k = set(), 16 if q.intent in ("literature_review", "compare", "gap_analysis") else 12
            for e in sorted(ev, key=lambda e: -e["score"]):
                key = (e["paper"], e["text"][:60])
                if key in seen: continue
                seen.add(key)
                conf = "HIGH" if e["type"] == "full_text" and e["score"] > .45 else "MEDIUM" if e["score"] > .3 else "LOW"
                r.evidence.append(Evidence(paper_idx=e["paper"], text=e["text"], page=e["page"], section=e["section"], source_type=e["type"], score=round(e["score"], 3), confidence=conf))
                if len(r.evidence) >= k: break
            step(f"{len(r.evidence)} evidence passages extracted")
            r.answer = self._synthesize(q, question, selected, r.evidence)
            r.answer, used, bad = validate(r.answer, len(selected))
            if bad: r.warnings.append(f"Removed invalid citation numbers: {bad}")
            if (n := uncited_paragraphs(r.answer)): r.warnings.append(f"{n} long paragraph(s) have no citation; treat as model synthesis.")
            r.references = [format_reference(i, p) for i, p in enumerate(selected, 1) if i in used] or [format_reference(i, p) for i, p in enumerate(selected, 1)]
            step(f"Citations verified: {len(used)} cited, {len(bad)} invalid removed")
            return self._finish(session, r, t0)
        except LLMError as e: r.error = f"Language model error: {e}. Check OPENAI_API_KEY and connectivity."
        except Exception as e:
            log.exception("pipeline failure"); r.error = f"Unexpected error ({type(e).__name__}): {str(e)[:200]}"
        return self._finish(session, r, t0, keep=False)

    def _synthesize(self, q, question, papers, evidence):
        plist = "\n".join(f"[{i}] {p.short()} | venue: {p.venue or 'n/a'} | DOI: {p.doi or 'n/a'} | citations: {p.citations if p.citations is not None else 'n/a'} | text: {'full text (partial)' if p.full_text else 'abstract/metadata only'}" for i, p in enumerate(papers, 1))
        ev = "\n\n".join(f"[{e.paper_idx}] ({e.source_type}, {e.section or 'n/a'}, page {e.page or 'n/a'}, {e.confidence}) {e.text}" for e in evidence)
        user = f"Question: {question}\nStructured intent: {q.model_dump_json()}\n\nPAPERS:\n{plist}\n\nEVIDENCE:\n{ev or '(none)'}"
        return self.llm.complete(prompts.COMMON + "\nTask: " + prompts.MODES.get(q.intent, prompts.MODES["qa"]), user)

    def _finish(self, session, r, t0, keep=True):
        r.seconds = round(time.time() - t0, 1)
        if keep: session.history += [("user", r.question), ("assistant", r.answer[:600])]
        log.info("request done in %.1fs, papers=%d evidence=%d error=%s", r.seconds, len(r.papers), len(r.evidence), bool(r.error))
        return r
