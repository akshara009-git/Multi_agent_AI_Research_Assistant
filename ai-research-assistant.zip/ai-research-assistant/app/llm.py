import json
from abc import ABC, abstractmethod
from pydantic import ValidationError
from .utils import get_logger, retry

log = get_logger("llm")


class LLMError(Exception): pass


class LLMProvider(ABC):
    @abstractmethod
    def complete(self, system: str, user: str, json_mode: bool = False) -> str: ...

    def structured(self, system: str, user: str, schema, retries: int = 2):
        sys_p = system + "\nReturn ONLY a JSON object matching this schema:\n" + json.dumps(schema.model_json_schema())
        for _ in range(retries + 1):
            raw = self.complete(sys_p, user, json_mode=True)
            try: return schema.model_validate_json(raw)
            except ValidationError as e:
                user += f"\n\nYour previous output was invalid ({str(e)[:300]}). Return corrected JSON only."
        raise LLMError("LLM returned invalid structured output")


class OpenAIProvider(LLMProvider):
    def __init__(self, api_key, model):
        from openai import OpenAI
        self.client = OpenAI(api_key=api_key, timeout=90); self.model = model

    def complete(self, system, user, json_mode=False):
        kw = {"response_format": {"type": "json_object"}} if json_mode else {}
        def call():
            r = self.client.chat.completions.create(model=self.model, temperature=0.2, **kw,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
            return r.choices[0].message.content or ""
        try: return retry(call, attempts=3, log=log)
        except Exception as e: raise LLMError(f"OpenAI request failed: {type(e).__name__}") from e
