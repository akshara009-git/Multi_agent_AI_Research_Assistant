import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import numpy as np
from app.models import Paper, ResearchQuery
from app.search import OpenAlexProvider, deduplicate, clean_doi, strip_tags, AcademicSearchProvider
from app.citations import validate, format_reference
from app.retrieval import chunk_pages, Embedder, VectorStore, extract_pdf
from app.ranking import rank
from app.config import Settings
from app.pipeline import Pipeline, Session
from app.llm import LLMProvider
from app.utils import DiskCache


class FakeLLM(LLMProvider):  # test-only
    def complete(self, system, user, json_mode=False):
        if json_mode: return ResearchQuery(intent="find_papers", topic="graph neural networks", search_queries=["graph neural networks"]).model_dump_json()
        return "GNNs are studied widely [1]. Invented [9]."


class OkProvider(AcademicSearchProvider):
    name = "ok"
    def _search(self, q, l, y): return [Paper(title="Graph Neural Networks: A Review", authors=["A Smith"], year=2023, abstract="We review graph neural networks and message passing.", doi="10.1/x")]


class BadProvider(AcademicSearchProvider):
    name = "bad"
    def _search(self, q, l, y): raise RuntimeError("down")


def settings(tmp): return Settings(cache_dir=Path(tmp))


def test_dedupe_by_doi_and_title():
    a = Paper(title="Deep RAG", doi="10.1/a", sources=["A"]); b = Paper(title="Different", doi=clean_doi("https://doi.org/10.1/A"), abstract="x", sources=["B"])
    c = Paper(title="Deep  RAG!", sources=["C"])
    out = deduplicate([a, b, c]); assert len(out) == 1 and set(out[0].sources) == {"A", "B", "C"}


def test_normalization_helpers():
    assert OpenAlexProvider.invert({"hello": [0], "world": [1]}) == "hello world"
    assert strip_tags("<jats:p>Hi <b>there</b></jats:p>") == "Hi there"


def test_citation_validation_removes_fake():
    out, used, bad = validate("A [1][2] B [7] C [1, 3]", 3)
    assert used == [1, 2, 3] and bad == [7] and "[7]" not in out


def test_reference_format_no_invention():
    assert "Venue not reported" in format_reference(1, Paper(title="T"))


def test_chunker_keeps_page_and_section():
    ch = chunk_pages([(3, "Introduction\n" + "word " * 500)]); assert ch[0]["page"] == 3 and ch[0]["section"] == "Introduction" and len(ch) > 1


def test_retrieval_and_ranking(tmp_path):
    e = Embedder(Settings(cache_dir=tmp_path), DiskCache(tmp_path)); assert e.mode == "hash"
    vs = VectorStore(e); vs.add([{"text": "quantum circuits optimization", "paper": 1}, {"text": "cooking pasta recipe", "paper": 2}])
    assert vs.search("quantum optimization", k=1)[0]["paper"] == 1
    ps = rank([Paper(title="Cooking pasta", abstract="recipes", sources=["Crossref"]), Paper(title="Quantum optimization", abstract="quantum circuits optimization", sources=["Crossref"])], ResearchQuery(topic="quantum optimization"), e)
    assert ps[0].title == "Quantum optimization"


def test_bad_pdf_returns_empty(tmp_path): assert extract_pdf("http://127.0.0.1:9/none.pdf", DiskCache(tmp_path)) == []


def test_pipeline_degrades_and_validates(tmp_path):
    c = DiskCache(tmp_path); p = Pipeline(settings(tmp_path), FakeLLM(), [BadProvider(c), OkProvider(c)])
    r = p.run(Session(), "gnn papers")
    assert not r.error and len(r.papers) == 1 and "[9]" not in r.answer and r.warnings
    assert r.status["bad"]["failed"] == 1 and r.status["ok"]["ok"] == 1


def test_all_sources_fail_gives_error_not_answer(tmp_path):
    c = DiskCache(tmp_path); r = Pipeline(settings(tmp_path), FakeLLM(), [BadProvider(c)]).run(Session(), "anything")
    assert r.error and not r.answer
