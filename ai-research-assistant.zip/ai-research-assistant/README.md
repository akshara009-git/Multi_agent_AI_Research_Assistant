# AI Research Assistant

A general-purpose research assistant: it understands any research question, plans a workflow, searches Semantic Scholar, OpenAlex, Crossref and arXiv, deduplicates, ranks, reads open-access PDFs, retrieves evidence with embeddings, writes a grounded answer, and verifies every citation.

## Architecture
```
Question → LLM query understanding (structured JSON, Pydantic-validated)
        → multi-query expansion → parallel provider search (retry, backoff, throttle, cache)
        → deduplicate (DOI / ids / title / authors / year) → rank (semantic + keywords + recency + citations + source)
        → open-access PDF → pages → sections → chunks → embeddings → vector search (top-k per paper)
        → mode-specific LLM prompt (explain, find, summarize, compare, review, gaps, ideas)
        → citation validator (removes [n] not in retrieved set) → answer + provenance
```
Why it is dynamic: intent, queries, year filters, paper count and workflow all come from the LLM's structured reading of your text. There are no stored questions or answers; every paper comes from a live API call.

## Install (Windows PowerShell)
```
cd ai-research-assistant
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
notepad .env
```
(If activation is blocked: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.)

## Environment variables
| Variable | What to put |
|---|---|
| OPENAI_API_KEY | Required. Key from platform.openai.com. |
| OPENAI_MODEL / OPENAI_EMBED_MODEL | Optional. Defaults gpt-4o-mini / text-embedding-3-small. |
| SEMANTIC_SCHOLAR_API_KEY | Optional. Free key gives better rate limits. |
| OPENALEX_API_KEY | Optional. Leave blank if you have none. |
| CROSSREF_EMAIL | Your email (Crossref "polite pool", faster). |
| ARXIV_ENABLED | true or false. |

## Run
```
streamlit run app/main.py
```
(or `python run.py`). Open http://localhost:8501.

## Test
```
pytest -q
```
Tests use a fake LLM and fake providers only inside `tests/`; the app itself never does.

## Try these
Latest approaches to hallucination detection in LLMs · Compare QAOA and VQE · Research gaps in federated learning for healthcare · Find papers after 2024 about quantum machine learning · Then follow up: "Compare the top five." · Suggest research directions in multimodal AI.

## Troubleshooting
- "OPENAI_API_KEY is missing": check `.env` is in the project root.
- Few results / warnings: a provider is rate-limited. Results still use the others; retry later or add API keys.
- No full text: most papers are paywalled; the app only reads public PDFs and labels abstract-only papers.
- Clear cache: delete files in `data/cache`.

## Structure
`app/` config, utils (cache, retry, throttle), models, llm (provider interface), prompts, search (4 providers + dedupe), retrieval (PDF, chunker, embeddings, vector store), ranking, citations, pipeline (planner + RAG), main (Streamlit UI) · `tests/` · `data/cache`.

## Limitations
- Citation validation checks that cited numbers map to retrieved papers, not that each sentence is semantically entailed by its evidence. Verify important claims.
- PDF extraction is plain-text only (no tables/figures); only first 20 pages, first 6 papers are read in full.
- Abstract-only analysis is flagged but shallower. Provider coverage and metadata vary.
- Numpy cosine store is in-memory per query (swap for FAISS/Chroma behind `VectorStore`).

## Future work
Entailment-based citation checking, FAISS/Chroma persistence, table extraction, citation-graph expansion, export to BibTeX, async providers.
